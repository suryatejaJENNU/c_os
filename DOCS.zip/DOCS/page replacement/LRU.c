#include <stdio.h>
#include <limits.h>

int isFound(int frames[], int fn, int val) {
    for (int i = 0; i < fn; i++) {
        if (frames[i] == val) {
            return 1;
        }
    }
    return 0;
}

void print(int frames[], int fn) {
    for (int i = 0; i < fn; i++) {
        printf("%d\t", frames[i]);
    }
    printf("\n");
}

int replace(int pages[], int frames[], int fn, int pn, int s) {
    int a[fn];
    for (int i = 0; i < fn; i++) {
        for (int j = s; j >= 0; j--) {
            if (frames[i] == pages[j]) {
                a[i] = j;
                break;
            }
        }
    }
    int mini = INT_MAX;
    int r = 0;
    for (int i = 0; i < fn; i++) {
        if (a[i] < mini) {
            mini = a[i];
            r = i;
        }
    }
    return r;
}

int main() {
    int fn, pn, r = 0, pf = 0, pt = 0;
    printf("Enter the number of pages:\n");
    scanf("%d", &pn);

    printf("Enter the number of frames:\n");
    scanf("%d", &fn);

    int frames[fn], pages[pn];
    printf("Enter the string:\n");
    for (int i = 0; i < pn; i++) {
        scanf("%d", &pages[i]);
    }

    for (int i = 0; i < fn; i++) {
        frames[i] = -1;
    }

    for (int i = 0; i < pn; i++) {
        if (isFound(frames, fn, pages[i])) {
            pt++;
            printf("%d is hit\n", pages[i]);
            print(frames, fn);
        } else {
            pf++;
            if (frames[r] == -1) {
                frames[r] = pages[i];
                printf("%d is page fault, added to frame\n", pages[i]);
                print(frames, fn);
                r++;
            } else {
                r = replace(pages, frames, fn, pn, i);
                frames[r] = pages[i];
                printf("%d is page fault, added to frame\n", pages[i]);
                print(frames, fn);
            }
        }
    }

    printf("Total number of page faults: %d\n", pf);
    printf("Total number of page hits: %d\n", pt);

    return 0;
}



/*Enter the number of pages:
20
Enter the number of frames:
4
Enter the string:
7 0 1 2 0 3 0 4 2 3 0 3 2 1 2 0 1 7 0 1
7 is page fault, added to frame
7	-1	-1	-1	
0 is page fault, added to frame
7	0	-1	-1	
1 is page fault, added to frame
7	0	1	-1	
2 is page fault, added to frame
7	0	1	2	
0 is hit
7	0	1	2	
3 is page fault, added to frame
3	0	1	2	
0 is hit
3	0	1	2	
4 is page fault, added to frame
3	0	4	2	
2 is hit
3	0	4	2	
3 is hit
3	0	4	2	
0 is hit
3	0	4	2	
3 is hit
3	0	4	2	
2 is hit
3	0	4	2	
1 is page fault, added to frame
3	0	1	2	
2 is hit
3	0	1	2	
0 is hit
3	0	1	2	
1 is hit
3	0	1	2	
7 is page fault, added to frame
7	0	1	2	
0 is hit
7	0	1	2	
1 is hit
7	0	1	2	
Total number of page faults: 8
Total number of page hits: 12*/
