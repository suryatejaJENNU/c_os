#include <stdio.h>

int isFound(int frames[], int fn, int val) {
    for (int i = 0; i < fn; i++) {
        if (frames[i] == val) {
            return 1;
        }
    }
    return 0;
}

void print(int frames[], int fn) {
    for (int i = 0; i < fn; i++) {
        printf("%d\t", frames[i]);
    }
    printf("\n");
}

int main() {
    int fn, pn, r = 0, pf = 0, pt = 0;
    printf("Enter the number of pages:\n");
    scanf("%d", &pn);

    printf("Enter the number of frames:\n");
    scanf("%d", &fn);

    int frames[fn], pages[pn];

    printf("Enter the string:\n");
    for (int i = 0; i < pn; i++) {
        scanf("%d", &pages[i]);
    }

    for (int i = 0; i < fn; i++) {
        frames[i] = -1;
    }

    for (int i = 0; i < pn; i++) {
        if (isFound(frames, fn, pages[i])) {
            pt++;
            printf("%d is hit\n", pages[i]);
            print(frames, fn);
        } else {
            pf++;
            if (r == fn)
                r = 0;
            frames[r] = pages[i];
            r++;
            printf("%d is page fault, added to frame\n", pages[i]);
            print(frames, fn);
        }
    }

    printf("Total number of page faults: %d\n", pf);
    printf("Total number of page hits: %d\n", pt);

    return 0;
}


/*Enter the number of pages:
7
Enter the number of frames:
3
Enter the string:
1 3 0 3 5 6 3
1 is page fault, added to frame
1	-1	-1	
3 is page fault, added to frame
1	3	-1	
0 is page fault, added to frame
1	3	0	
3 is hit
1	3	0	
5 is page fault, added to frame
5	3	0	
6 is page fault, added to frame
5	6	0	
3 is page fault, added to frame
5	6	3	
Total number of page faults: 6
Total number of page hits: 1
     */
