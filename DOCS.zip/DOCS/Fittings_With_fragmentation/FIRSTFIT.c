#include <stdio.h>

int main() {
    int n;
    printf("Enter no of pages:\n");
    scanf("%d", &n);

    int pages[n];
    printf("Enter the sizes of pages:\n");
    for (int i = 0; i < n; i++) {
        scanf("%d", &pages[i]);
    }

    int blocks;
    printf("Enter no of blocks:\n");
    scanf("%d", &blocks);

    int blocks_sizes[blocks];
    printf("Enter the sizes of blocks:\n");
    for (int i = 0; i < blocks; i++) {
        scanf("%d", &blocks_sizes[i]);
    }

    int visited[blocks], j;
    for (int i = 0; i < n; i++) {
        for (j = 0; j < blocks; j++) {
            if (blocks_sizes[j] >= pages[i] && visited[j] != 1) {
                printf("page %d is allocated in frame %d\n", i + 1, j + 1);
                blocks_sizes[j] -= pages[i];
                visited[j] = 1;
                break;
            }
        }
        if (j == blocks) {
            int sum = 0;
            for (int j = 0; j < blocks; j++) {
                sum += blocks_sizes[j];
                if (blocks_sizes[j] >= pages[i]) {
                    printf("page %d undergoes internal fragmentation\n", i + 1);
                    break;
                }
            }
            if (j == blocks && sum >= pages[i]) {
                printf("page %d undergoes external fragmentation\n", i + 1);
            }
        }
    }

    return 0;
}

