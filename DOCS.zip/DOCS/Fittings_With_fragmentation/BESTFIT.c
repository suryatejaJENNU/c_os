#include <stdio.h>
#include <limits.h>

int main() {
    int n;
    printf("Enter no of pages:\n");
    scanf("%d", &n);

    int pages[n];
    printf("Enter sizes of pages:\n");
    for (int i = 0; i < n; i++) {
        scanf("%d", &pages[i]);
    }

    int blocks;
    printf("Enter no of blocks:\n");
    scanf("%d", &blocks);

    int blocks_sizes[blocks];
    printf("Enter sizes of blocks:\n");
    for (int i = 0; i < blocks; i++) {
        scanf("%d", &blocks_sizes[i]);
    }

    int visited[blocks];
    for (int i = 0; i < blocks; i++) {
        visited[i] = 0;
    }

    for (int i = 0; i < n; i++) {
        int index = -1, mini = INT_MAX, j;
        for (j = 0; j < blocks; j++) {
            if (blocks_sizes[j] >= pages[i] && visited[j] != 1 && mini > (blocks_sizes[j] - pages[i])) {
                mini = blocks_sizes[j] - pages[i];
                index = j;
            }
        }
        if (index != -1) {
            printf("process %d is allocated in frame %d\n", i + 1, index + 1);
            blocks_sizes[index] -= pages[i];
            visited[index] = 1;
            continue;
        }
        if (j == blocks) {
            int sum = 0;
            for (int j = 0; j < blocks; j++) {
                sum += blocks_sizes[j];
                if (blocks_sizes[j] >= pages[i]) {
                    printf("page %d undergoes internal fragmentation\n", i + 1);
                    break;
                }
            }
            if (j == blocks && sum >= pages[i]) {
                printf("page %d undergoes external fragmentation\n", i + 1);
            }
        }
    }

    return 0;
}

