#include <stdio.h>
#include <limits.h>

struct item {
    int stime;
    int btime;
    int ctime;
    int tatime;
    int wtime;
    int rtime;
    int all;
    int ibtime;
};

int visited[100] = {0};

int findmin(struct item arr[], int n) {
    int mini = INT_MAX;
    int index = 0;
    for (int i = 0; i < n; i++) {
        if (arr[i].stime < mini) {
            mini = arr[i].stime;
            index = i;
        }
        if (arr[i].stime == mini) {
            if (arr[i].btime < arr[index].btime) {
                mini = arr[i].stime;
                index = i;
            }
        }
    }
    return index;
}

int findminBT(struct item arr[], int start, int n) {
    int mini = INT_MAX;
    int index = 0;
    for (int i = 0; i < n; i++) {
        if (!visited[i] && arr[i].stime <= start && mini > arr[i].btime) {
            mini = arr[i].btime;
            index = i;
        }
        if (!visited[i] && arr[i].stime <= start && mini == arr[i].btime) {
            if (arr[i].stime < arr[index].stime) {
                mini = arr[i].btime;
                index = i;
            }
        }
    }
    return index;
}

int main() {
    printf("Enter the value of n: ");
    int n, total = 0;
    scanf("%d", &n);
    printf("Enter the Arrival times and Burst times:\n");

    struct item arr[n];
    for (int i = 0; i < n; i++) {
        scanf("%d %d", &arr[i].stime, &arr[i].btime);
        arr[i].ibtime = arr[i].btime;
        total += arr[i].btime;
    }

    int start, count = 0;
    start = findmin(arr, n);

    while (count <= total) {
        int i = findminBT(arr, start, n);
        arr[i].btime -= 1;
        if (arr[i].all == 0) {
            if (arr[i].stime != 0) {
                arr[i].all = start;
            }
        }
        start++;
        if (arr[i].btime == 0) {
            visited[i] = 1;
            arr[i].ctime = start;
            arr[i].tatime = arr[i].ctime - arr[i].stime;
            arr[i].wtime = arr[i].tatime - arr[i].ibtime;
            arr[i].rtime = arr[i].all - arr[i].stime;
        }
        count++;
    }

    printf("AT\tBT\tCT\tTAT\tWT\tRT\n");
    for (int i = 0; i < n; i++) {
        printf("%d\t%d\t%d\t%d\t%d\t%d\n", arr[i].stime, arr[i].ibtime, arr[i].ctime, arr[i].tatime, arr[i].wtime, arr[i].rtime);
    }

    return 0;
}

