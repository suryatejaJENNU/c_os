#include <stdio.h>
#include <stdlib.h>

int main() {
    printf("Enter the starting value & ending value: ");
    int start, end, n, head;
    scanf("%d %d", &start, &end);

    printf("Enter the number of tracks: ");
    scanf("%d", &n);

    int arr[n];

    printf("Enter the Track values:\n");
    for (int i = 0; i < n; i++) {
        scanf("%d", &arr[i]);
    }

    printf("Enter the head position: ");
    scanf("%d", &head);

    int res = 0;
    int i = 0;
    int visited[n];
    for (int k = 0; k < n; k++) {
        visited[k] = 0;
    }

    printf("Out sequence: ");
    int curr = head;

    while (i < n) {
        int mini = __INT_MAX__;
        int index = -1;
        for (int j = 0; j < n; j++) {
            if (!visited[j] && abs(arr[j] - curr) < mini) {
                if (arr[j] != curr || arr[j] == head) {
                    mini = abs(arr[j] - curr);
                    index = j;
                }
            }
        }
        res += abs(arr[index] - curr);
        printf("%d ", arr[index]);
        curr = arr[index];
        visited[index] = 1;
        i += 1;
    }
    printf("\n");
    printf("Total number of head movements: %d\n", res);

    return 0;
}

