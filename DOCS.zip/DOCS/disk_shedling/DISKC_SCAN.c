#include <stdio.h>
#include <stdlib.h>

void right(int arr[], int n, int start, int end, int head) {
    int index = -1;
    for (int i = 0; i < n; i++) {
        if (arr[i] > head) {
            index = i;
            break;
        }
    }
    int res = 0;
    if (arr[index - 1] == head) {
        res += abs(end - head);
        res += abs(end - start);
        res += abs(start - arr[index - 2]);
        for (int i = index - 1; i < n; i++) {
            printf("%d ", arr[i]);
        }
        for (int i = 0; i < index - 1; i++) {
            printf("%d ", arr[i]);
        }
        printf("\n");
    } else if (arr[index - 1] != head) {
        res += abs(end - head);
        res += abs(end - start);
        res += abs(start - arr[index - 1]);
        printf("%d ", head);
        for (int i = index; i < n; i++) {
            printf("%d ", arr[i]);
        }
        for (int i = 0; i <= index - 1; i++) {
            printf("%d ", arr[i]);
        }
        printf("\n");
    }
    printf("Right traversal value = %d\n", res);
}

void left(int arr[], int n, int start, int end, int head) {
    int index = -1;
    for (int i = 0; i < n; i++) {
        if (arr[i] > head) {
            index = i;
            break;
        }
    }
    int res = 0;
    if (arr[index - 1] == head) {
        res += abs(head - start);
        res += abs(start - end);
        res += abs(end - arr[index]);
        for (int i = index - 1; i >= 0; i--) {
            printf("%d ", arr[i]);
        }
        for (int i = n - 1; i >= index; i--) {
            printf("%d ", arr[i]);
        }
        printf("\n");
    } else if (arr[index - 1] != head) {
        res += abs(head - start);
        res += abs(start - end);
        res += abs(end - arr[index]);
        printf("%d ", head);
        for (int i = index - 1; i >= 0; i--) {
            printf("%d ", arr[i]);
        }
        for (int i = n - 1; i >= index; i--) {
            printf("%d ", arr[i]);
        }
        printf("\n");
    }
    printf("Left traversal value = %d\n", res);
}

int main() {
    int start, end;
    printf("Enter the starting and Ending positions of the track: ");
    scanf("%d %d", &start, &end);

    int n;
    printf("Enter the value of n: ");
    scanf("%d", &n);

    int arr[n];

    printf("Enter the Tracks:\n");
    for (int i = 0; i < n; i++) {
        scanf("%d", &arr[i]);
    }

    int head;
    printf("Enter the head position: ");
    scanf("%d", &head);

    // Sorting the array for ease of traversal
    for (int i = 0; i < n; i++) {
        for (int j = i + 1; j < n; j++) {
            if (arr[i] > arr[j]) {
                int temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }
    }

    char t;
    printf("Enter the direction for Traverse (r for right, l for left): ");
    scanf(" %c", &t);

    if (t == 'r') {
        right(arr, n, start, end, head);
    } else if (t == 'l') {
        left(arr, n, start, end, head);
    } else {
        printf("Invalid direction.\n");
    }

    return 0;
}

